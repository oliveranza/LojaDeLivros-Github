package com.spring.ifpb.resouces;


public enum CategoriaLivro {
	
	ROMANCE,
	SUSPENSE,
	DRAMA,
	TERROR,
	AUTO_AJUDA,
	BIOGRAFIA,
	CONTOS,
	FABULAS,
	FANTASIA;

}
